package com.whitecloak.Twitter;
import java.io.*;
public class Main {

    public static void main(String[] args) {

      Twitter t = new Twitter("scores.txt");
      t.readFile();
      t.setSentence("accomplished ache");
      //System.out.println("The sentence you typed is: "+);
      double score = t.computeSentiment();
      System.out.println("The score is: "+score);
      String sentiment = t.sentiment();
      System.out.println("The sentiment is: "+sentiment);



    }

}