package com.whitecloak.MachineExercises;

import java.util.HashMap;
import java.util.Scanner;

public class Magic {
    public String word;

    Magic(String word){
            this.word=word;
        }
    public void isPalindrome() {
            String temp = "";
            for (int i = word.length()-1; i >= 0; i--) {
                temp += word.charAt(i);
            }
            if (temp.equals(word)) {
                System.out.println("Palindrome: True");
            } else {
                System.out.println("Palindrome: False");
            }
    }

    public void skyscrapper(){
            String retWord="";
            for(int i=0;i< word.length();i++){
                int index=i%2;
                if(index==1){
                    retWord+=Character.toString(word.charAt(i));
                }else{
                retWord+=Character.toString(word.charAt(i)).toUpperCase();
                }
            }
            System.out.println("Skyscrapper: "+retWord);
    }
    public void vowel(){
            String q="";
            q=word.replaceAll("[^ aeiou]","");
            System.out.println("Vowels: "+q);
    }
    public void consonant(){
            String w="";
            w=word.replaceAll("[aeiou]","");
            System.out.println("Consonants: "+w);

    }
    public void countEachLetter(){
            HashMap<Character, Integer> equivalent=new HashMap<Character, Integer>();
                char letter[]=word.toCharArray();
                for(char q: letter){
                    if(equivalent.containsKey(q)){
                        equivalent.put(q,equivalent.get(q)+1);
                    }else {
                    equivalent.put(q,1);
                    }
                }
                System.out.println("Letter counter:");
            for(char i:equivalent.keySet()){
                System.out.println(i+"-"+equivalent.get(i));
            }
    }
}
