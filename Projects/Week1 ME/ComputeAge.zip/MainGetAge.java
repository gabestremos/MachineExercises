package com.whitecloak.MachineExercises;

import java.util.Scanner;

public class MainGetAge {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name=input.nextLine();
        System.out.print("Enter your birthday(YYYY-mm-dd): ");
        String bday=input.nextLine();
        try {
            ComputeAge get=new ComputeAge(name,bday);
            get.getAge();
        }catch (Exception e){
            System.out.println("You entered invalid birthday format!");
        }
    }
}
