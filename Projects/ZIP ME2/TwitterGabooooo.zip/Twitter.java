package com.whitecloak.Twitter;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Twitter extends TwitterAbstract {
    Twitter(String filename) {
        super(filename);
    }
    int count=0;
    int wordCount=0;
    @Override
    void readFile() {
        String fileName="/Users/gabestremos/IdeaProjects/Module1 MachineProblems/src/com/whitecloak/Twitter/scores.txt";
        String lineValue;


        try {
            FileReader fReader=new FileReader(fileName);
            BufferedReader bReader=new BufferedReader(fReader);
            while ((lineValue=bReader.readLine())!=null){
                 words[count]=lineValue.split("\\s")[0];
                 scores[count]=lineValue.split("\\s")[1];
                 count++;
                //System.out.println(lineValue);
            }
        }catch (FileNotFoundException e){
            System.out.println("No available file.");
        }catch (IOException e){
            System.out.println("Error reading file.");
        }
        //System.out.println(words[25]+scores[25]);
    }

    @Override
    void setSentence(String sentence) {
        String perWord[]=sentence.split("\\s");
        for(int i=0;i<perWord.length;i++){
            for(int q=0;q<words.length;q++){
                if(perWord[i].equals(words[q])){
                    score+=Integer.parseInt(scores[q]);
                    wordCount++;
                    System.out.println("Word included: "+perWord[i]);
                }
            }
        }
    }

    @Override
    double computeSentiment() {
        score=score/wordCount;
        return score;
    }

    @Override
    String sentiment() {
        if(score>0){
            return "Positive!";
        }else if(score<0){
            return "Negative!";
        }else{
            return "Neutral!";
        }
    }
}
