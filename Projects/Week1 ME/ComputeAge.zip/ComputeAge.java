package com.whitecloak.MachineExercises;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class ComputeAge {
    public String name;
    public String birthday;

    ComputeAge(String name,String birthday){
        this.name=name;
        this.birthday=birthday;
    }
    public void getAge(){
        LocalDate bday=LocalDate.parse(birthday);           //convert string to local date
        Period age=Period.between(bday,LocalDate.now());    //difference between given date and local date today
        System.out.println("Hi "+name+"!");
        System.out.println("Your age as of today is: "+age.getYears());
    }

}
