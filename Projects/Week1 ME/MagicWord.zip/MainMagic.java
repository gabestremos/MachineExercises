package com.whitecloak.MachineExercises;

import java.util.Scanner;

public class MainMagic {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        System.out.print("Enter a word:");
        String word=input.nextLine();
        Magic MagicWord=new Magic(word);
        MagicWord.isPalindrome();
        MagicWord.skyscrapper();
        MagicWord.vowel();
        MagicWord.consonant();
        MagicWord.countEachLetter();
    }
}
